package com.mycompany.myapp;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Map;

public class LoginActivity extends Activity {

    private EditText phoneEditText;
    private EditText passwordEditText;
    private Button loginButton;
    private TextView responseTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main2);

        phoneEditText = findViewById(R.id.phoneno);
        passwordEditText = findViewById(R.id.password);
        loginButton = findViewById(R.id.loginBtn);
        responseTextView = findViewById(R.id.resultView);

        // Handle login button click
        loginButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					login();
				}
			});
    }

    private void login() {
        String phone = phoneEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        // Validate inputs
        if (TextUtils.isEmpty(phone) || phone.length() != 10) {
            responseTextView.setText("Invalid phone number.");
            return;
        }

        if (TextUtils.isEmpty(password) || password.length() < 8) {
            responseTextView.setText("Password must be at least 8 characters.");
            return;
        }

        // Make login request
        new LoginTask().execute(phone, password);
    }

    private class LoginTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {
            String phone = params[0];
            String password = params[1];

            try {
                // API URL
                String urlString = "https://www.sebaspokenenglish.com/auth/v1/teacher/login/verify";
                URL url = new URL(urlString);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();

                // Setup the request
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Accept", "application/json");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setDoOutput(true);

                // Prepare JSON body
                JSONObject jsonRequest = new JSONObject();
                jsonRequest.put("phone", phone);
                jsonRequest.put("password", password);

                // Send the request
                try (OutputStream os = conn.getOutputStream()) {
                    byte[] input = jsonRequest.toString().getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                // Capture response
                int responseCode = conn.getResponseCode();
                StringBuilder response = new StringBuilder();
                response.append("Response Code: ").append(responseCode).append("\n");

                // Get response headers
                Map<String, List<String>> headers = conn.getHeaderFields();
                for (Map.Entry<String, List<String>> header : headers.entrySet()) {
                    response.append(header.getKey()).append(": ").append(header.getValue()).append("\n");
                }

                // Read the response body
                BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
                String responseLine;
                StringBuilder responseBody = new StringBuilder();
                while ((responseLine = br.readLine()) != null) {
                    responseBody.append(responseLine.trim());
                }

                response.append("\nResponse Body: ").append(responseBody.toString());
                return response.toString();

            } catch (Exception e) {
                e.printStackTrace();
                return "Error occurred: " + e.getMessage();
            }
        }

        @Override
protected void onPostExecute(String result) {
    responseTextView.setText(result);
    responseTextView.setVisibility(View.VISIBLE); // Make it visible
}
    }
}